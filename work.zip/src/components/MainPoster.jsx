import React from 'react'
import banner from '../images/banner.png'
const MainPoster = () => {
  return (
    <div className='h-auto w-full'>
      <img src={banner}></img>
    </div>
  )
}

export default MainPoster
